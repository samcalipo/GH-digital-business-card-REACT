import React from 'react'

export default function Interests(){
    return(
        <div className="interests-div">
            <h3 className="h3-title">Interests</h3>
            <p className="p-paragraph">LOVE learning and experiencing new things. Am told 
            i'm spontaneous and quite the character. I Just enjoy 
            creating in general, that could be content(YT, TT),
            art, animation etc. Also do love history and technology.</p>
        </div>
    )
}